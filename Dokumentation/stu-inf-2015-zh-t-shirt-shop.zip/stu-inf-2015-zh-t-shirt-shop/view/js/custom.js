redirectTime = "1500";
redirectURL = "localhost/home";



function timedRedirect(){
	setTimeout("window.location = redirectURL",redirectTime);
}

