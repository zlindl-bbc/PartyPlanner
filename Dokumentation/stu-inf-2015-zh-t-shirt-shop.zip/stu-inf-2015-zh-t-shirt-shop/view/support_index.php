


<form class="form-horizontal" action="/support/SupportKontaktieren" method="post">
	<div class="component" data-html="true">
		<div class="form-group">
			<label class="col-md-2 control-label" for="email">Mail</label>
			<div class="col-md-4">
				<input id="email" name="email" type="text" placeholder="Mail"
					class="form-control input-md">
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-2 control-label" for="">Bemerkung</label>
			<div class="col-md-4">
				<textarea id="bemerkung" name="bemerkung"
					placeholder="Ihre Bemerkung hier" class="form-control input-md">
				</textarea>
			</div>
		</div>
		<div class="form-group">
			<label class="col-md-2 control-label" for="send">&nbsp;</label>
			<div class="col-md-4">
				<input id="send" name="send" type="submit" class="btn btn-primary">
			</div>
		</div>
<?php
if ($_SESSION['Support']=="true") {
	echo "<p>Ihre Anfrage wurde abgeschickt und sie werden in K�rze eine e-Mail von unserem Support erhalten";
	$_SESSION['Support']="false";
}
?>

	</div>
</form>


</div>