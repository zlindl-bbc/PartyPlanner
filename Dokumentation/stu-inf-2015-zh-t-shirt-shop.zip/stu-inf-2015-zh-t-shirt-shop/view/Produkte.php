

<div class = mad>Hier sind deine Treffer</div>


<article class="hreview open special">

<?php if (empty($ProdukteModel)): ?>
             <div class="dhd">
                    <h2 class="item title">Hoppla! Keine Produkte gefunden.</h2>
             </div>
       <?php else: ?>
             <?php foreach($ProdukteModel as $Produkt): ?>
                    <div class="einzelnesProdukt">
                    	<a href="/produkt/showdetailprodukt/<?php echo $Produkt->ID?>">
                    	<img src="/resources/T-Shirt<?php echo $Produkt->ID ?>.jpg">
                    	<br><?php echo $Produkt->Produkt_Name?><br><?php echo $Produkt->Preis?>.-
                    </a> 
                    </div>
             <?php endforeach ?>
       <?php endif ?>
</article>


