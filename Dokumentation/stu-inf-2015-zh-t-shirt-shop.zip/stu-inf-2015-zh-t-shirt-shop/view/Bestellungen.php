<?php
require_once("model/BestellungenModel.php");

class ProduktController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => '',
				'heading' => 'Produkt'
		) );
		$view->display ();
	}
	
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
	
}	