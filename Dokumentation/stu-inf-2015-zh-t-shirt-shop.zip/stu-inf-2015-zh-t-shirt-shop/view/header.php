<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title><?php echo $title;?></title>

<link href="/view/css/bootstrap.manipulated.css" rel="stylesheet">
<link href="/view/css/custom.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Indie+Flower' rel='stylesheet' type='text/css'>

</head>

<body>

	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse"
					data-target=".navbar-collapse">
					<span class="sr-only">Navigation</span> <span class="icon-bar"></span>
					<span class="icon-bar"></span> <span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href=""><img src="/resources/logo.png" height=50px></img></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav navbar-right">
					<li class="divider">&nbsp;</li>
					<li><a href="/Home">Home</a></li>
					<li class=dropdown>
						<a href="/Home" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
						Products <span class="caret"></span></a>
					<ul class=dropdown-menu>
					<li><a href="/produkte/showAllProductFromCategorie/men">Men</a></li>
					<li><a href="/produkte/showAllProductFromCategorie/Woman">Woman</a></li>
					<li><a href="/produkte/showAllProductFromCategorie/Kid">KIDS</a></li>
					</ul>
				</li>
					
					<?php
					if(empty($_SESSION["IsAuthenticated"])){
						echo"<li><a href='/user/login'>Login</a></li>";
					}
					else {
						echo"<li><a href='/user/logout'>Logout</a></li>";
					}
					?>
					
					<li><a href="/UserCreate/create">Registrieren</a></li>
					<li><a href="/support">Support</a></li>
					<li><a href='/Cart/ShowCart'><span class='glyphicon glyphicon-shopping-cart'></span></a>
					
				</ul>
			</div>
		</div>
	</div>

	<div>

		<div>

<div class=inhalt>

			<h1><?php echo $heading;?></h1>