        <hr>
        <footer>
          <p>&copy; ICT Berufsbildungcenter AG 2014</p>
        </footer>
      </div>

      <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
      <script src="/view/js/bootstrap.min.js"></script>
      <script src="/view/js/custom.js"></script>
      
      <script type="text/javascript">
	      $('.carousel').carousel({
	    	  interval: 4000
	    	})
		</script>

      
    </div>
  </body>
</html>
