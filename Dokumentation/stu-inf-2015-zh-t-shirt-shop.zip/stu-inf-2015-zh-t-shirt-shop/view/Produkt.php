



<article class="hreview open special">



<?php if (empty($produktModel)): ?>
             <div class="dhd">
                    <h2 class="item title">Hoppla! Produkt konnte nicht gefunden werden.</h2>
             </div>
       <?php else: ?>
             <?php foreach($produktModel as $Produkt): ?>
                    <div class="float-left" id=produktbild>
                    	<img src="/resources/T-Shirt<?php echo $Produkt->ID ?>.jpg"></div><div class=float-left>
                    	<br><h3><?php echo $Produkt->Produkt_Name?></h3><br><h5>Preis  :<?php echo $Produkt->Preis?>.-</h5>
                    	<br><br><?php echo $Produkt->bemerkung?><br><br>
                    	<br><a href='/Cart/AddToCart/<?php echo $Produkt->ID?>' class='btn btn-primary'>
                        	<span class='glyphicon glyphicon-shopping-cart'></span> Add to cart</a>
                    </div>
             <?php endforeach ?>
       <?php endif ?>
</article>

<div class=float-left>

<p>Das Produkt wurde mit einer Durschnittsbewertung von<?php echo $DurchschnittsBewertung?> bewertet.

<form class="form-horizontal" action="/produkt/BewertungAbgeben/<?php echo $Produkt ->ID?>" method="post">
<input type="hidden" name="selectedProduct" value=<?php echo $Produkt ->ID?>>
	<div>
	 <div class="rating">
          <input type="radio" name="rating" value="0" checked /><span id="hide"></span>
          <input class="star" type="radio" name="rating" value="1" /><span></span>
          <input class="star" type="radio" name="rating" value="2" /><span></span>
          <input class="star" type="radio" name="rating" value="3" /><span></span>
          <input class="star" type="radio" name="rating" value="4" /><span></span>
          <input class="star" type="radio" name="rating" value="5" /><span></span>
     </div>
		<div class="form-group produkt">
			<label class="col-md-2 control-label produkt" for="send">&nbsp;</label>
			<div class="col-md-4">
				<input id="send" name="send" type="submit" class="btn btn-primary">
			</div>
		</div>
	</div>
</form>	
<form class="form-horizontal " action="/produkt/BewertungLoeschen/<?php echo $Produkt ->ID?>" method="post">
<input type="hidden" name="selectedProduct" value=<?php echo $Produkt ->ID?>>			
	<div>	
		<div class="form-group produkt">
			<label class="col-md-2 control-label produkt" for="send">&nbsp;</label>
			<div class="col-md-4">
				<input id="send" name="send" value="Loeschen" type="submit" class="btn btn-primary">
			</div>
		</div>
	</div>
</form>
</div>
