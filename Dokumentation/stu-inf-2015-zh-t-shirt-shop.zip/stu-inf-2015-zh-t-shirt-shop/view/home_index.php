<head>
<link href="/view/css/custom.css" rel="stylesheet">
</head>

<body>
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
<ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>
  
  <div class="carousel-inner" role="listbox">
    <div class="item active">
	<a href="/produkte/showAllProductFromCategorie/men">
      <img src="/resources/T-Shirt1.jpg">
      <img src="/resources/Men.jpg">
      <img src="/resources/T-Shirt5.jpg">
	</a>
    </div>
    <div class="item">
    <a href="/produkte/showAllProductFromCategorie/Woman">
      <img src="/resources/T-Shirt2.jpg">
      <img src="/resources/Woman.jpg">
      <img src="/resources/T-Shirt8.jpg">
     </a>
    </div>
    <div class="item">
	<a href="/produkte/showAllProductFromCategorie/Kid">
      <img src="/resources/T-Shirt7.jpg">
      <img src="/resources/Kids.jpg">
      <img src="/resources/T-Shirt3.jpg">
      </a>
    </div>
  </div>
  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
 
  
  
<!--  	<div class=carousel-inner role="listbox">
		<div class=item-active alt="Herren">
		<a href="/produkte/showAllProductFromCategorie/men">
			<img class=produktkategorieimg alt="" src="/resources/T-Shirt1.jpg">
			</a>
		</div>
		<div class=item alt="Kids">
		<a href="/produkte/showAllProductFromCategorie/Kid">
			<img class=produktkategorieimg alt="" src="/resources/T-Shirt4.jpg">
			</a>
		</div>
		<div class=item alt="Damen">
		<a href="/produkte/showAllProductFromCategorie/Woman">
			<img class=produktkategorieimg alt="" src="/resources/T-Shirt2.jpg">
			</a>
		</div>
		<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>-->
		</div>
		</div>
		</div>
</body>