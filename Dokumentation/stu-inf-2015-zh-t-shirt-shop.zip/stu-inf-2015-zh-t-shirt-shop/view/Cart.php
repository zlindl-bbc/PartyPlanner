

<div class=Warenkorb>
<?php if (empty($Products)): ?>
             <div class="dhd">
                    <h2 class="item title">Noch keine Produkte im Warenkorb</h2>
                    <a class='btn btn-primary' href='/Home'>Home</a>
             </div>
       <?php else: ?>
       		<table>
            <?php foreach ($Products as $Produkt){
            	echo "<tr><td>";
            	echo $Produkt->Produkt_Name.":";
             	echo "</td><td>";
            	
            	echo $Produkt->Preis.".-";?>
            	</td><td>
            	<a style="margin:2px;" href='/Cart/DeleteFromCart/<?php echo $Produkt->ID?>' class='btn btn-primary'>
                        	<span class='glyphicon glyphicon-remove'></span>Entfernen</a>
                </td></tr>
            	<?php }?>
                </table>
             <a style="margin:2px;" href='/Cart/SaveInDatabase' class='btn btn-primary'>
             <span class='glyphicon glyphicon-shopping-cart'></span>Kaufen</a>
       <?php endif ?>     
       
       
       </div>