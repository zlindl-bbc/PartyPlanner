

<?php 


if ($_SESSION["registering"]=="true"){

	echo"<p>Sie sind nun registriert und k�nnen sich �ber Login einloggen</p>";
	$_SESSION["registering"]=="false";
}elseif ($_SESSION["IsAuthenticated"]=="true"){
	
	echo"<p>Sie sind nun eingeloggt</p>";
}


?>

