<?php
class BewertungResult{
	
	private $Bewertung;
	
	public function setBewertung($Bewertung)
	{
		$this->Bewertung=$Bewertung;
	}
	
	public function getBewertung()
	{
		return $this->Bewertung;
	}
}