<?php

class Dispatcher
{
       public static function dispatch()
       {
             session_start();

             if (!isset($_SESSION["IsAuthenticated"]))
             {
                    
                    
                    if ($_SERVER['REQUEST_URI'] == "/user/doLogin")
                    {	
                    	require_once ("controller/UserController.php");
                    	$controller = new UserController();
                   		$controller->doLogin();
                    }
                    elseif ($_SERVER['REQUEST_URI'] == "/UserCreate/create")
                    {
                    	require_once ("controller/UserCreateController.php");
                    	$controller = new UserCreateController();
                    	$controller->create();
                    }
                    elseif ($_SERVER['REQUEST_URI'] == "/UserCreate/doCreate")
                    {	
                    	require_once ("controller/UserCreateController.php");
                    	$controller = new UserCreateController();
                    	$controller->doCreate();
                    }
                    else
                    {
                    	require_once ("controller/UserController.php");
                    	$controller = new UserController();
                    	$controller->login();
                    }
             }
             else 
             {
                    $url = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
                    
                    $runOnEclipseDebugMode = strrpos($url[0], "?XDEBUG_SESSION_START", -strlen($url[0])) !== FALSE;      
                    $controllerName = (!empty($url[0]) && !$runOnEclipseDebugMode)  ? ucfirst($url[0]) . 'Controller' : 'DefaultController';
                    
                    $method         = !empty($url[1]) ? $url[1] : 'index';
                    $args           = array_slice($url, 2);
                    
                    require_once ("controller/$controllerName.php");
                    $controller = new $controllerName();
                    
                    call_user_func_array(array($controller, $method), $args);
                    
                    unset($controller);
             }

       }
}
