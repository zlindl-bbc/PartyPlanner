<?php
class PermissionResult
{
	private $userId;
	
	public function setUserId($userId)
	{
		$this->userId=$userId;
	}
	
	public function getUserId()
	{
		return $this->userId;
	}
	
	public function isLoggedIn()
	{
		return isset($this->userId);
	}
	
}