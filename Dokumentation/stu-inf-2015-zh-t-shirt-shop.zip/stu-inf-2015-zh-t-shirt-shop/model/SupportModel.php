<?php
require_once ('lib/Model.php');

class SupportModel extends Model {
	protected $tableName = 'support';
	
	
	
	
	
	public function SupportKontaktieren($email,$bemerkung){
		$query = "INSERT INTO $this->tableName (email, bemerkung) VALUES (?, ?)";
		
		$statement = ConnectionHandler::getConnection()->prepare ($query);
		$statement->bind_param ( 'ss', $email, $bemerkung );
		
		
		if (!$statement->execute()) {
			throw new Exception($statement->error);
		}
		
	}



}