<?php
require_once ('lib/Model.php');
require_once ('lib/BewertungResult.php');

class ProduktModel extends Model {

	protected $tablename = 'produkt';

	public function showdetailproduktForCart($ID) {

		$sql="SELECT * FROM produkt WHERE ID = ? ";

		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 'i', $ID );

		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}

		$result = $statement->get_result ();
		if (!$result) {
			throw new Exception($statement->error);
		}

		return $result->fetch_object();

	}


	public function showdetailprodukt($ID) {

		$sql="SELECT * FROM $this->tablename WHERE ID = ? ";

		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 'i', $ID );

		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}

		$result = $statement->get_result ();
		if (!$result) {
			throw new Exception($statement->error);
		}

		$rows = array();
		while ($row = $result->fetch_object()) {
			$rows[] = $row;
		}

		return $rows;

	}
	
	
	public function istbewertet($ProduktID,$UserID) {
	
		$sql="SELECT ID FROM bewertung tablename WHERE Produkt_ID = ? and User_ID = ?";
	
		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 'ii', $ProduktID, $UserID);
	
		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}
	
		$result = $statement->get_result ();
		if (!$result) {
			throw new Exception($statement->error);
		}
	
		$row = $result->fetch_object();	
		if ($row==null){
			return false;
		}
		else{
			return true;
		}
	
	}

	public function BewertungAbgeben($Bewertung, $Produkt_ID, $User_ID) {
		$query = "INSERT INTO bewertung (Bewertung,User_ID,Produkt_ID) VALUES (?,?,?)";
	
		$statement = ConnectionHandler::getConnection ()->prepare ( $query );
		$statement->bind_param ( 'iii', $Bewertung, $User_ID, $Produkt_ID );
	
		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}
	}

       public function BewertungLoeschen($Produkt_ID, $User_ID) {
             
             $query= "Delete from bewertung where User_ID=? and Produkt_ID=?";
             
             $statement = ConnectionHandler::getConnection ()->prepare ( $query );
             $statement->bind_param ( 'ii',$User_ID, $Produkt_ID );
             
             if (! $statement->execute ()) {
                    throw new Exception ( $statement->error );
             }

       }
	
	
	public function BewertungAnzeigen($Produkt_ID){
		
		$query = "Select Bewertung from bewertung where Produkt_ID=?";
		
		$statement = ConnectionHandler::getConnection ()->prepare ( $query );
		$statement->bind_param ( 'i', $Produkt_ID );
		
		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}
		
		$result = $statement->get_result ();
		if (!$result) {
			throw new Exception($statement->error);
		}
		
		$rows = array();
		while ($row = $result->fetch_object()) {
			$rows[] = $row;
		}
		
		return $rows;
		
			
		}
}
	
	



