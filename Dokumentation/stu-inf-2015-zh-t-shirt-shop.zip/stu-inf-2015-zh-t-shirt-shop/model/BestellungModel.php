<?php
require_once ('lib/Model.php');
class BestellungModel extends Model {
	protected $tablename = 'bestellung';
	public function insertintoBestellung($UserID) {
		$date = date ( "Y-m-d" );
		$sql = "INSERT INTO $this->tablename (User_ID,Datum) VALUES (?,?)";
		
		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 'is', $UserID, $date );
		$statement->execute();
		
		return $statement->insert_id;
	}
}