<?php
require_once ('lib/Model.php');

class UserModel extends Model {
	protected $tableName = 'users';
	public function checkPermission($email, $password) {
		// $password = sha1($password);
		$query = "SELECT * from $this->tableName where email = ? and passwort = ?";
		
		$statement = ConnectionHandler::getConnection ()->prepare ( $query );
		$statement->bind_param ( 'ss', $email, $password );
		
		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}
		
		$result = $statement->get_result ();
				
		if ($result->num_rows == 0) {
			return new PermissionResult();
		} else {
			
			$row = $result->fetch_object();
				
			$permissionResult = new PermissionResult();
			$permissionResult->setUserId($row->id);
			return $permissionResult;
		}
	}

	
	public function create($email, $password) {
	
		//$password = sha1($password);
		
		$query = "INSERT INTO $this->tableName (email, passwort) VALUES (?, ?)";
		
		$statement = ConnectionHandler::getConnection()->prepare ($query);
		$statement->bind_param ( 'ss', $email, $password );
		
		
		if (!$statement->execute()) {
			throw new Exception($statement->error);
		}
		
	}
}
