<?php
require_once ('lib/Model.php');

class produkt_bestellungModel extends Model {

	protected $tablename = 'produkt_bestellung';
	public function insertintoProdukte_Bestellung($ProduktID,$Bestellung_ID) {

		$sql="INSERT INTO $this->tablename (Produkt_ID,Bestellung_ID) VALUES (?,?)";

		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 'ii', $ProduktID, $Bestellung_ID);
		$statement->execute();
	}
}