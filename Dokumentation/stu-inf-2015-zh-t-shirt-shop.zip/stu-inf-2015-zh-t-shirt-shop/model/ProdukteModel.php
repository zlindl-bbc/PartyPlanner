<?php
require_once ('lib/Model.php');

class ProdukteModel extends Model {
	public function loadProductsByCategories($categories) {
		
		$sql="SELECT * FROM produkt WHERE kategorie = ? ORDER BY Produkt_Name ASC";
		
		$statement = ConnectionHandler::getConnection ()->prepare ( $sql );
		$statement->bind_param ( 's', $categories );
		
		if (! $statement->execute ()) {
			throw new Exception ( $statement->error );
		}
		
		$result = $statement->get_result ();
		if (!$result) {
			throw new Exception($statement->error);
		}
				
		$rows = array();
		while ($row = $result->fetch_object()) {
			$rows[] = $row;
		}
		
		return $rows;

	}
}
