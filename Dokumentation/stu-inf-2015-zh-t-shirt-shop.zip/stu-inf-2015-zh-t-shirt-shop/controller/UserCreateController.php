<?php

require_once ('model/UserModel.php');
require_once("lib/PermissionResult.php");

class UserCreateController {

public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Registrierung',
				'heading' => 'Registrieren'
		) );
		$view->display ();
	}


public function create() {
	$view = new View ( 'user_create' );
	$view->display ();
}

public function doCreate() {
	if (isset($_POST ['email'])&& isset($_POST ['password'])) {
		$email = $_POST ['email'];
		$password = $_POST ['password'];
			
		$userModel = new UserModel ();
		$userModel->create ( $email, $password );
		$_SESSION["registering"]="true";
	}

	$view = new View('login');
	$view->display();
	header ("Location: /user/login/");
}

public function __destruct() {
	$view = new View ( 'footer' );
	$view->display ();
}
}