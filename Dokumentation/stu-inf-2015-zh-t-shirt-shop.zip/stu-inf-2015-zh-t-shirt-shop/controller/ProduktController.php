<?php
require_once("model/produktModel.php");
require_once("lib/BewertungResult.php");

class ProduktController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => '',
				'heading' => 'Produkt'
		) );
		$view->display ();
	}
	
	public function showdetailprodukt($ID){
			$view = new View ( 'Produkt' );
			$produktModel = new produktModel();
			$Produktdaten = $produktModel->showdetailprodukt($ID);
			$_SESSION['Bewertung']='false';
			$view->produktModel = $Produktdaten;
			
			$bewertungResult=$produktModel->BewertungAnzeigen($ID);

			$bewertungen = count($bewertungResult);
			
			$sumBewertungen = 0;
			foreach ($bewertungResult as $bewertung)
			{
				$sumBewertungen += $bewertung->Bewertung;
			}

			$view->DurchschnittsBewertung = round($sumBewertungen/$bewertungen);
			$view->display ();
			
	}
		
		
		
	public function BewertungAbgeben($ID){
		if (isset($_POST['rating'])&& (isset($_POST['selectedProduct']))){
			$Bewertung=$_POST['rating'];
			$Produkt_ID = $_POST['selectedProduct'];
			$User_ID = $_SESSION['UserID'];
			
			$produktModel = new produktModel();
			$bewertet=$produktModel->istbewertet($Produkt_ID,$User_ID);
			if ($bewertet==false){
			
				$produktModel= new ProduktModel();
				$produktModel->BewertungAbgeben($Bewertung, $Produkt_ID,$User_ID);
				$_SESSION['Bewertung']='true';
			}
		}
		if($_SESSION['Bewertung']=='true'){
			echo "Die Bewertung wurde abgegeben";
			echo '<h1 onclick="JavaScript:timedRedirect()">Weiter... </h1>';
			unset($_SESSION['Bewertung']);
		}
		header ( "Location: /produkt/showdetailprodukt/". $ID);
	}
		
		
// 	public function BewertungAnzeigen(){
// 		$Produkt_ID = $_POST['selectedProduct'];
		
// 		$produktModel = new ProduktModel();
// 		$bewertungResult=$produktModel->BewertungAnzeigen($Produkt_ID);
		
// 		$bewertungen = count($bewertungResult);
// 		array_sum($bewertungResult);
// 		$DurchschnittsBewertung = $bewertungResult/$bewertungen;
		
// 		$view = new View ( 'produkt' );
		

// 		$view->Mathias = $DurchschnittsBewertung;
// 		$view->display ();		
// 	}
		
		
	public function BewertungLoeschen($ID)
	{
		$Produkt_ID = $_POST['selectedProduct'];
		$User_ID = $_SESSION['UserID'];
		
		$produktModel= new ProduktModel();
		$produktModel->BewertungLoeschen($Produkt_ID,$User_ID);
		$view = new View('bewertung');
		$view->display();
		header ( "Location: /produkt/showdetailprodukt/". $ID);
	}
		
	public function __destruct() {
			$view = new View ( 'footer' );
			$view->display ();
		}
	
	}
		
		?> 
