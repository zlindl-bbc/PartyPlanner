<?php
require_once ('model/UserModel.php');
require_once("lib/PermissionResult.php");

class UserController {
		
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Login',
				'heading' => 'Login' 
		) );
		$view->display ();
	}
	public function index() {
		$userModel = new UserModel ();
		
		$view = new View ( 'user_index' );
		$view->users = $userModel->readAll ();
		$view->display ();
	}
	
	public function login() {
		$view = new View ( 'login' );
		$view->display ();
	}
	public function logout() {
		session_destroy ();
		unset ( $_SESSION ["IsAuthenticated"] );
		$view = new View ( 'login' );
		$view->display ();
		header ( "Refresh:0" );
	}
	public function doLogin() {
		$view = new View ( 'login' );
		
		if (!empty( $_POST ['email'] ) && !empty( $_POST ['password'] )) {
			
			$email = $_POST ['email'];
			$password = $_POST ['password'];
			
			
			$userModel = new UserModel ();
			$permissionResult = $userModel->checkPermission( $email, $password );
			if ($permissionResult->isLoggedIn()) {
				
				$_SESSION ["UserID"] = $permissionResult->getUserId();
				$_SESSION ["IsAuthenticated"] = "true";
				$_SESSION ["registering"] = "false";
				header ( "Location: /home" );
				return;
				
			} else {
				$view = new View ( 'login' );
				$view->ErrorMessage = "Username or password invalid!";
				$view->display();
				return;
			}
		}
		
		$view->ErrorMessage = "Username or password not set!";
		$view->display ();
	}

	public function delete($id) {
		$userModel = new UserModel ();
		$userModel->deleteById ( $id );
		
		$this->index ();
	}
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
	
}

