 <?php
class HomeController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Home',
				'heading' => 'Home' 
		) );
	$view->display ();
	}
	
	public function index() {
		$view = new View ( 'home_index' );
		$view->display();
	 }
	
	
	
	
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
}