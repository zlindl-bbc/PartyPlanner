<?php

require_once("model/BestellungenModel.php");

class ProduktController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Bestellungen',
				'heading' => 'Bestellungen'
		) );
		$view->display ();
	}

	public function showallBestellungen(){
		$BestellungModel = new BestellungModel();
		
	}

	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}

}