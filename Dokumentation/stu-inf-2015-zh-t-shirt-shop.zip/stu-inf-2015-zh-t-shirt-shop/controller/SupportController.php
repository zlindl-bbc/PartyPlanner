<?php
require_once ('model/SupportModel.php');
class SupportController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Support',
				'heading' => 'Support' 
		) );
		$view->display ();
	}
	
	
	
	public function SupportKontaktieren() {
		if (isset ( $_POST ['email'] ) && isset ( $_POST ['bemerkung'] )) {
			$email = $_POST ['email'];
			$bemerkung = $_POST ['bemerkung'];
			
			$supportModel = new SupportModel();
			$supportModel->SupportKontaktieren ( $email, $bemerkung );
		}
		$_SESSION['Support']='true';
		$view = new View('support_index');
		$view->display();
	}
	
	
	
	public function index() {
		$_SESSION['Support']='false';
		$view = new View ( 'support_index' );
		$view->display();
	}
	
	
	
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
}
		