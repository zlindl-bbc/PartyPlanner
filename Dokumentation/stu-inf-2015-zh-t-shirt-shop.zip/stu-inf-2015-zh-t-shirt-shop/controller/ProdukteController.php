<?php
require_once("model/ProdukteModel.php");
class ProdukteController {
	public function __construct() {
		$view = new View ( 'header', array (
				'title' => '',
				'heading' => 'Produkte' 
		) );
		$view->display ();
	}
	
	public function showAllProductFromCategorie($categorie)
	{
		$view = new View ( 'Produkte' );
		$produkteModel = new ProdukteModel();
		$produkts = $produkteModel->loadProductsByCategories($categorie);
		$view->ProdukteModel = $produkts;
		$view->display ();
	}
	
	public function index() {
		
		$produkteModel = new ProdukteModel();
		$produkts = $produkteModel->loadProductsByCategories("Kid");
		
		$view = new View ( 'Produkte' );
		$view->ProdukteModel = $produkts;
		$view->display ();
	}
	
	
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
}

?>