<?php

require_once("model/ProduktModel.php");
require_once("model/BestellungModel.php");
require_once("model/produkt_bestellungModel.php");

class CartController{

	public function __construct() {
		$view = new View ( 'header', array (
				'title' => 'Warenkorb',
				'heading' => 'Warenkorb'
		) );
		$view->display ();
	}
	
	
	public function AddToCart($ID){
		
		if(!isset($_SESSION['cart_items'])){
			$_SESSION['cart_items'] = array();
		}
		
		array_push($_SESSION['cart_items'], $ID);
		
		header ( "Location: /produkt/showdetailprodukt/" . $ID);
	}
	
	public function DeleteFromCart($ID){
		
		if(!isset($_SESSION['cart_items'])){
			return;
		}
		
		$ListOfItems = $_SESSION['cart_items'];
		$ListOfItems=array_diff($ListOfItems,array($ID));
		$_SESSION['cart_items']=$ListOfItems;
		header ("Location: /Cart/ShowCart/");
		
		
	}
	
	public function ShowCart(){
		
		if(!isset($_SESSION['cart_items'])){
			$_SESSION['cart_items'] = array();
		}
		
		$ListOfItems = $_SESSION['cart_items'];
		
		$produktModel = new ProduktModel();
		
		$rows = array();
		foreach ($ListOfItems as $item)
		{
			$row = $produktModel->showdetailproduktForCart($item);
			$rows[] = $row;
		}
		
		$view = new View ( 'Cart' );
		
		$view->Products = $rows;
		$view->display ();
	}
	
	public function SaveInDatabase(){
	
		if(isset($_SESSION['cart_items'])){
			
			$ItemIDs=$_SESSION['cart_items'];
			$UserID=$_SESSION['UserID'];
			
			$BestellungModel = new BestellungModel();
			$produkt_bestellungModel= new produkt_bestellungModel();
			
			$ID=$BestellungModel->insertintoBestellung($UserID);
			
			foreach($ItemIDs as $ProduktID){
			$produkt_bestellungModel->insertintoProdukte_Bestellung($ProduktID,$ID);
		}
		}
		unset($_SESSION['cart_items']);
		header ("Location: /Cart/ShowCart/");
	
	}
	
	public function __destruct() {
		$view = new View ( 'footer' );
		$view->display ();
	}
	
}