<?php

return array(

    'database' => array(
        'host'     => 'localhost',
        'username' => 'root',
        'password' => '',
        'database' => 'db_kuhle_shirts',
    ),

);
